﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using System.ComponentModel;

namespace WorkingDaysCalculation
{
    public class FirstWorkingDateOfTheMonth : CodeActivity
    {

        [Category("Input")]
        [RequiredArgument]
        public InArgument<int> Year { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<int> Month { get; set; }

        [Category("Input")]
        public InArgument<DateTime[]> NonWorkingDays { get; set; }

        [Category("Output")]
        public OutArgument<DateTime> Result { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            var varYear = Year.Get(context);
            var varMonth = Month.Get(context);
            var varNonWorkingDays = NonWorkingDays.Get(context);


            DateTime FirstBusinessDay = new DateTime();
            int monthFirstDay = 1;
            if (varNonWorkingDays == null)
            {
                varNonWorkingDays = new DateTime[] { };
            }
            while (monthFirstDay > 0)
            {
                var currentDate = new DateTime(varYear, varMonth, monthFirstDay);
                if (currentDate.DayOfWeek < DayOfWeek.Saturday && currentDate.DayOfWeek > DayOfWeek.Sunday && !varNonWorkingDays.Contains(currentDate))
                {
                    FirstBusinessDay = currentDate;
                    monthFirstDay = 0;
                }
                else
                {
                    monthFirstDay = monthFirstDay + 1;
                }
            }

            Result.Set(context, FirstBusinessDay);

        }
    }
}

