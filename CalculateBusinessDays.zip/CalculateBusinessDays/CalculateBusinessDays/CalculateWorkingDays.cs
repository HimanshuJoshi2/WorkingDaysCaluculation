﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using System.ComponentModel;

namespace WorkingDaysCalculation
{
    public class CalculateWorkingDays : CodeActivity
    {

        [Category("Input")]
        [RequiredArgument]
        public InArgument<DateTime> FirstDate { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<DateTime> LastDate { get; set; }

        [Category("Input")]
        public InArgument<DateTime[]> NonWorkingDays { get; set; }

        [Category("Output")]
        public OutArgument<int> ResultDays { get; set; }

        protected override void Execute(CodeActivityContext context)
        {           
            var varFirstDate = FirstDate.Get(context);
            var varEndDate = LastDate.Get(context);
            var varNonWorkingDays = NonWorkingDays.Get(context);

            //Initialise First Date and End Date
            varFirstDate = varFirstDate.Date;
            varEndDate = varEndDate.Date;
            
            if (varFirstDate > varEndDate) //FirstDate Date is Greater than date throw Exception
            {
                throw new ArgumentException("First date shouldn't be greater than End date");
            }
            TimeSpan span = varEndDate - varFirstDate;
            int businessDays = span.Days + 1;
            int fullWeekCount = businessDays / 7;           
            if (businessDays > fullWeekCount * 7)
            {
                // we are here to find out if there is a 1-day or 2-days weekend
                // in the time interval remaining after subtracting the complete weeks
                int firstDayOfWeek = (int)varFirstDate.DayOfWeek;
                int lastDayOfWeek = (int)varEndDate.DayOfWeek;
                if (lastDayOfWeek < firstDayOfWeek)
                    lastDayOfWeek += 7;
                if (firstDayOfWeek <= 6)
                {
                    if (lastDayOfWeek >= 7)// Both Saturday and Sunday are in the remaining time interval
                        businessDays -= 2;
                    else if (lastDayOfWeek >= 6)// Only Saturday is in the remaining time interval
                        businessDays -= 1;
                }
                else if (firstDayOfWeek <= 7 && lastDayOfWeek >= 7)// Only Sunday is in the remaining time interval
                    businessDays -= 1;
            }

            //Remove weekends from the calculated days
            businessDays -= fullWeekCount + fullWeekCount;

            if (varNonWorkingDays != null) // Is NonWorkingDays Null
            {
                if (varNonWorkingDays.Length > 0) //The Length Of NonWorkingDays Greater Than 0
                {
                    foreach (DateTime nonWorkingDay in varNonWorkingDays) //Iterate Through Each Time the NonWorkingDays Provided
                    {
                        DateTime bh = nonWorkingDay.Date;
                        if (varFirstDate <= bh && bh <= varEndDate)
                            --businessDays;
                    }
                }
            }           
            //Return the calculated Business Days To the Output Arguements ResultDays
            ResultDays.Set(context, businessDays);

        }
    }



}
