﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Activities;
using System.ComponentModel;

namespace WorkingDaysCalculation
{
    public class LastWorkingDateOfTheMonth : CodeActivity
    {
        [Category("Input")]
        [RequiredArgument]
        public InArgument<int> Year { get; set; }

        [Category("Input")]
        [RequiredArgument]
        public InArgument<int> Month { get; set; }

        [Category("Input")]
        public InArgument<DateTime[]> NonWorkingDays { get; set; }

        [Category("Output")]
        public OutArgument<DateTime> Result { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            var varYear = Year.Get(context);
            var varMonth = Month.Get(context);
            var varNonWorkingDays = NonWorkingDays.Get(context);


            DateTime lastBusinessDate = new DateTime();
            int monthLastday = DateTime.DaysInMonth(varYear, varMonth);
            if (varNonWorkingDays == null)
            {
                varNonWorkingDays = new DateTime[] { };
            }
            while (monthLastday > 0)
            {
                var currentDate = new DateTime(varYear, varMonth, monthLastday);
                if (currentDate.DayOfWeek < DayOfWeek.Saturday && currentDate.DayOfWeek > DayOfWeek.Sunday && !varNonWorkingDays.Contains(currentDate))
                {
                    lastBusinessDate = currentDate;
                    monthLastday = 0;
                }
                else
                {
                    monthLastday = monthLastday - 1;
                }
            }
            Result.Set(context, lastBusinessDate);

        }
    }
}
